<?php $__env->startSection('sidenav'); ?>
	<div class="menu">
     	<ul class="list">
			<li class="header">MAIN NAVIGATION</li>
			<li>
				<a href="<?php echo e(route('home')); ?>">
					<i class="material-icons">home</i>
					<span>Home</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('expense')); ?>">
					<i class="material-icons">show_chart</i>
					<span>Expenses</span>
				</a>
			</li>
			<li >
				<a href="<?php echo e(route('trips')); ?>">
					<i class="material-icons">directions_bus</i>
					<span>Trips</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('dtr')); ?>">
					<i class="material-icons">access_time</i>
					<span>Daily Time Record</span>
				</a>
			</li>
			<li class="active">
				<a href="<?php echo e(route('od')); ?>">
					<i class="material-icons">arrow_upward</i>
					<span>Outbound Deliveries</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('ca')); ?>">
					<i class="material-icons">monetization_on</i>
					<span>Cash Advance</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('purchases')); ?>">
					<i class="material-icons">bookmark_border</i>
					<span>Purchases</span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('sales')); ?>">
					<i class="material-icons">shopping_cart</i>
					<span>Sales</span>
				</a>
			</li>
		</ul>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="block-header">
			<h2>Outbound Deliveries Dashboard</h2>
		</div>
	</div>
	<div class="modal fade" id="od_modal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2 class="modal_title">Add User</h2>
					</div>
					<div class="body">
						<form class="form-horizontal " id="od_form">
							<input type="hidden" name="id" id="id" value="">
							<input type="hidden" name="button_action" id="button_action" value="">
							
							<div class="row clearfix">
								<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
									<label for="name">Outbound Ticket</label>
								</div>
								<div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" id="ticket" name="ticket" readonly="readonly" value="" class="form-control" required>
										</div>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
									<label for="type">Commodity</label>
								</div>
								<div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
									<div class="form-group">
										<select type="text" id="commodity" name="commodity" class="form-control" placeholder="Select item" required style="width:100%;">
											<?php $__currentLoopData = $commodity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?> Price: <?php echo e($a->price); ?>(<?php echo e($a->suki_price); ?>)</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
									<label for="name">Destination</label>
								</div>
								<div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="text" id="destination" name="destination" class="form-control"   required>
										</div>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
									<label for="type">Driver</label>
								</div>
								<div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
									<div class="form-group">
										<select type="text" id="driver_id" name="driver_id" class="form-control" placeholder="Select driver" required style="width:100%;">
											<?php $__currentLoopData = $driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($a->emp_id); ?>"><?php echo e($a->lname); ?>, <?php echo e($a->fname); ?> <?php echo e($a->mname); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
									<label for="type">Company</label>
								</div>
								<div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
									<div class="form-group">
										<select type="text" id="company" name="company" class="form-control" placeholder="Select company" required style="width:100%;">
											<?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
									<label for="name">Plate #</label>
								</div>
								<div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
									<div class="form-group">
										<select type="text" id="plateno" name="plateno" class="form-control" placeholder="Select truck" required style="width:100%;">
											<?php $__currentLoopData = $trucks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?> (<?php echo e($a->plate_no); ?>)</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
							</div>

							<div class="row clearfix">
								<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
									<label for="name">No. of Liters</label>
								</div>
								<div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
									<div class="form-group">
										<div class="form-line">
											<input type="number" id="liter" name="liter" class="form-control"   required>
										</div>
									</div>
								</div>
							</div>

							<div class="row clearfix">
							 	<div class="modal-footer">
									<button type="submit" id="add_delivery" class="btn btn-link waves-effect">SAVE CHANGES</button>
									<button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row clearfix">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="card">
				<div class="header">
					<h2>List of users as of <?php echo e(date('Y-m-d ')); ?></h2>
						<ul class="header-dropdown m-r--5">
							<li class="dropdown">
								<button type="button" class="btn bg-grey btn-xs waves-effect m-r-20 open_od_modal"><i class="material-icons">library_add</i></button>
							</li>
						</ul>
					</div>
					<div class="body">
						<div class="table-responsive">
							<table id="deliverytable" class="table table-bordered table-striped table-hover  ">
								<thead>
									<tr>
										<th>Ticket No</th>
										<th>Commodity</th>
										<th>Destination</th>
										<th>Company</th>
										<th>Driver</th>
										<th>Plate No.</th>
										<th>Liters</th>
										<th width="50">Action</th>
									</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on("click","#link",function(){
            $("#bod").toggleClass('overlay-open');
        });

        $(document).ready(function() {

            $.extend( $.fn.dataTable.defaults, {
                "language": {
                    processing: 'Loading.. Please wait'
                }
            });

			//OUTBOUND DELIVERIES datatable starts here
			$('#od_modal').on('hidden.bs.modal', function (e) {
				$(this)
				.find("input,textarea,select")
					.val('')
					.end()
				.find("input[type=checkbox], input[type=radio]")
					.prop("checked", "")
					.end();
			})
                    
			var deliveriestable = $('#deliverytable').DataTable({
				dom: 'Bfrtip',
				buttons: [
				],
				processing: true,
				serverSide: true,
				ajax: "<?php echo e(route('refresh_deliveries')); ?>",
				columns: [
					{data: 'outboundTicket', name: 'outboundTicket'},
					{data: 'commodity_name', name: 'commodity_name'},
					{data: 'destination', name: 'destination'},
					{data: 'name', name: 'name'},
					{data:'fname',
						render: function(data, type, full, meta){
							return full.fname +" "+ full.mname+" "+full.lname;
						}
					},
					{data: 'plateno', name: 'plateno'},
					{data: 'fuel_liters', name: 'fuel_liters'},
					{data: "action", orderable:false,searchable:false}
				]
			});

			function refresh_delivery_table(){
				deliveriestable.ajax.reload(); //reload datatable ajax
			}

			$(document).on('click','.open_od_modal', function(){
				$('.modal_title').text('Add Delivery');
				$('#button_action').val('add');
				$.ajax({
					url:"<?php echo e(route('refresh_id')); ?>",
					method: 'get',
					data: { temp: 'temp' },
					dataType:'json',
					success:function(data){
						var t=0;
						if(data[0].temp!=null){
							t = data[0].temp;
						}
						console.log(data);
						$("#driver_id").val('').trigger('change');
						$("#company").val('').trigger('change');
						$("#commodity").val('').trigger('change');
						$("#plateno").val('').trigger('change');
						var a = parseInt(t);
						var b = a + 1;
						var c = new Date();
						var twoDigitMonth = ((c.getMonth().length+1) === 1)? (c.getMonth()+1) : '0' + (c.getMonth()+1);
						var currentDate = c.getFullYear()+ twoDigitMonth + c.getDate();
						$('#ticket').val(currentDate+b);
						console.log( $('#ticket').val());
						$('#od_modal').modal('show');
					}
				})
			});

			$(document).on('click', '#add_delivery', function(){
				event.preventDefault();
				$.ajax({
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					url:"<?php echo e(route('add_delivery')); ?>",
					method: 'POST',
					dataType:'text',
					data: $('#od_form').serialize(),
					success:function(data){
						$("#driver_id").val('').trigger('change');
						$("#company").val('').trigger('change');
						$("#commodity").val('').trigger('change');
						swal("Success!", "Record has been added to database", "success")
						$('#od_modal').modal('hide');
						refresh_delivery_table();
					},
					error: function(data){
						swal("Oh no!", "Something went wrong, try again.", "error")
					}
				})
			});

			$(document).on('click', '.update_delivery', function(){
				var id = $(this).attr("id");
				$.ajax({
					url:"<?php echo e(route('update_delivery')); ?>",
					method: 'get',
					data:{id:id},
					dataType:'json',
					success:function(data){
						$('#button_action').val('update');
						$('#id').val(id);
						$('#ticket').val(data.outboundTicket);
						$('#destination').val(data.destination);
						$("#driver_id").val(data.driver_id).trigger('change');
						$("#company").val(data.company_id).trigger('change');
						$("#commodity").val(data.commodity_id).trigger('change');
						$("#plateno").val(data.plateno).trigger('change');
						$('#liter').val(data.fuel_liters);
						$('#od_modal').modal('show');
						$('.modal_title').text('Update Role');
						refresh_delivery_table();
					}
				})
			});

			$(document).on('click', '.delete_delivery', function(){
				var id = $(this).attr('id');
				swal({
					title: "Are you sure?",
					text: "Delete this record!",
					type: "warning",
					showCancelButton: true,
					confirmButtonClass: "btn-danger",
					confirmButtonText: "Yes, delete it!",
					closeOnConfirm: false
				},
				function(){
					$.ajax({
						url:"<?php echo e(route('delete_delivery')); ?>",
						method: "get",
						data:{id:id},
						success:function(data){
							refresh_delivery_table();
						}
					})
					swal("Deleted!", "The record has been deleted.", "success");
				});
			});
			//OUTBOUND DELIVERIES Datatable ends here

			$('#plateno').select2({
               dropdownParent: $('#od_modal'),
               placeholder: 'Select a truck'
            });

            $('#driver_id').select2({
                dropdownParent: $('#od_modal'),
                 placeholder: 'Select a driver'
            });
            $('#commodity').select2({
                dropdownParent: $('#od_modal'),
                 placeholder: 'Select an item'
            });
            $('#company').select2({
                dropdownParent: $('#od_modal'),
                 placeholder: 'Select a company'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>