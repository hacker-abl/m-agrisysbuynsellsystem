<html>
	<h1><strong> M-AGRI BUY AND SELL SYSTEM</strong></h1>
	<p>by ScriptedScript Web Systems</p>
	<p align="center"><img src="https://scontent.fmnl6-1.fna.fbcdn.net/v/t1.0-9/27332038_1611561705576297_6590667790777360517_n.jpg?oh=406023b6af361944ec4ff16839f61273&oe=5B10B26E" height="400" width="400"></p>
	<h2>Developers</h2>
	<ul>
		<li>Benedict Carl S. Badilles</li>
		<li>Floyd Francis M. Matabilas</li>
		<li>Jan Rey M. Suarez</li>
		<li>Allen B. Lamparas</li>
		<li>Ximdrake C. Asidor</li>
	</ul>
	<h2>Usage</h2>
	<p> 1. Install Laravel</p>
	<p> 2. Run Composer</p>
	<p> 2. Run "npm install"</p>
	<p> 3. Run laravel migrations -> "php artisan migrate"</p>
	<p> 4. Run "php artisan db:seed"</p>
	<h2>Sample Accounts</h2>
	<table>
		<thead>
			<tr>
				<th>Username</th>
				<th>Password</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>admin</td>
				<td>password</td>
			</tr>
			<tr>
				<td>cashier</td>
				<td>password</td>
			</tr>
		</tbody>
	</table>
</html>
